package com.packt.jdeveloper.cookbook.shared.bc.extensions;

import oracle.jbo.server.ViewRowImpl;

public class ExtViewRowImpl extends ViewRowImpl {
}
