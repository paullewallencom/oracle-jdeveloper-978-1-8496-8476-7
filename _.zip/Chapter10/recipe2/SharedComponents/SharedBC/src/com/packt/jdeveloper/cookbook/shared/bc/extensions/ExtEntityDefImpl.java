package com.packt.jdeveloper.cookbook.shared.bc.extensions;

import oracle.jbo.server.EntityDefImpl;

public class ExtEntityDefImpl extends EntityDefImpl {
}
